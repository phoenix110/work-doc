package com.wondersgroup.zjjk.enums;

/**
 * 慢病接口所有类型
 * 
 * @author liuhui
 *
 */
public enum SlowDiseaseType implements AbstractEnumInterface<SlowDiseaseType> {

	NULL("0", "未知专病", " "),

	DISEASE_TUMOR_ZX("1", "肿瘤报卡", "ZjjkZlHzxxBgks"),

	DISEASE_DIABETES_ZX("2", "糖尿病报卡", "ZjjkTnbHzxxBgks"),

	DISEASE_HEART_ZX("3", "心脑报卡", "ZjjkXnxgBgks"),

	DISEASE_HARM("4", "伤害报卡", "ZjmbShjcBgks"),

	DISEASE_DIE("5", "死亡报卡", "ZjmbSwBgks"),

	DISEASE_DIABETES_CF("6", "糖尿病初访卡", "ZjjkTnbSfks"),

	DISEASE_DIABETES_SF("7", "糖尿病随访卡", "ZjjkTnbSfks"),

	DISEASE_HEART_CF("8", "心脑初访卡", "ZjjkXnxgCfks"),

	DISEASE_HEART_SF("9", "心脑随访卡", "ZjjkXnxgSfks"),

	DISEASE_TUMOR_CF("10", "肿瘤初访卡", "ZjjkZlCcsfks"),

	DISEASE_TUMOR_SF("11", "肿瘤随访卡", "ZjjkZlSfks"),

	BACK_DISEASE("12", "校验结果", "ZjjkDzCxs");
	private String value;

	private String name;

	private String desc;

	private SlowDiseaseType(String value, String name, String desc) {
		this.value = value;
		this.name = name;
		this.desc = desc;
	}

	@Override
	public String getValue() {
		return this.value;
	}

	@Override
	public String getDesc() {
		return this.desc;
	}

	@Override
	public SlowDiseaseType genEnumByIntValue(String intValue) {
		for (SlowDiseaseType item : SlowDiseaseType.values()) {
			if (item.getValue().equals(intValue))
				return item;
		}
		return null;
	}

	@Override
	public SlowDiseaseType getDefaultType() {
		return SlowDiseaseType.NULL;
	}

}
