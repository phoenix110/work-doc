

--1 �޸���������Ϊ24 Сʱ��
  alter session set nls_timestamp_format='yyyy-mm-dd hh24:mi:ss.ff';
-- ����jobs
 BEGIN  
 DBMS_SCHEDULER.CREATE_JOB (  
   job_name           =>  'Validate_Data',  
   job_type           =>  'STORED_PROCEDURE',  
   job_action         =>  'ZJJK_VALIDATE.Proc_Zjjk_Exe_Validate',  
   start_date         =>  timestamp'2016-05-27 00:00:00',  
   repeat_interval    =>  'FREQ=DAILY;INTERVAL=1');  
 END;  
 
